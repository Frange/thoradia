﻿/*
 * PLUGIN SeedingTime
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.seedingTime		= "Ukończono";
 theUILang.addTime		= "Dodano";

thePlugins.get("seedingtime").langLoaded();