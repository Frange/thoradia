﻿/*
 * PLUGIN UNPACK
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.unpack		= "Распаковать";
 theUILang.unpackPath		= "Путь (пусто - в директорию закачки)";
 theUILang.unzipNotFound	= "Плагин Unpack: Программа unzip недоступна пользователю rTorrent.";
 theUILang.unrarNotFound	= "Плагин Unpack: Программа unrar недоступна пользователю rTorrent.";
 theUILang.unpackEnabled	= "Автораспаковывать, если метка торрента соответствует";
 theUILang.unpackTorrents	= "При распаковке данных всего торрента добавлять к пути";
 theUILang.unpackAddLabel	= "Метку торрента";
 theUILang.unpackAddName	= "Имя торрента";

thePlugins.get("unpack").langLoaded();