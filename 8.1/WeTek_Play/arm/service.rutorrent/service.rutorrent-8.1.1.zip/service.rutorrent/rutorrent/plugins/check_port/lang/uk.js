﻿/*
 * PLUGIN CHECK_PORT
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.checkPort		= "Перевірити стан порту";
 theUILang.portStatus		= [
 				  "Стан порту невідомий",
 				  "Порт закрито",
 				  "Порт відкрито"
 				  ];

thePlugins.get("check_port").langLoaded();