#!/bin/sh
# $1 - users profile
# $2 - pid
# $3 - filename

echo "$3" >> "$1"/"$2".tmp