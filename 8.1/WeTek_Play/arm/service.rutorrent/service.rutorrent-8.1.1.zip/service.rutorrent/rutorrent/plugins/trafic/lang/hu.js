﻿/*
 * PLUGIN TRAFFIC
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.traf 		= "Traffic";
 theUILang.perDay		= "Per day";
 theUILang.perMonth		= "Per month";
 theUILang.perYear		= "Per year";
 theUILang.allTrackers		= "All trackers";
 theUILang.ClearButton		= "Clear";
 theUILang.ClearQuest		= "Do you really want to clear statistics for selected tracker(s)?";
 theUILang.selectedTorrent	= "Selected torrent(s)";
 theUILang.ratioDay		= "Ratio/day";
 theUILang.ratioWeek		= "Ratio/week";
 theUILang.ratioMonth		= "Ratio/month";
