﻿/*
 * PLUGIN UNPACK
 *
 * Hungarian language file.
 *
 * Author: Tiby08
 */

 theUILang.unpack		= "Kicsomagolás";
 theUILang.unpackPath		= "Csomagolja ki ide(Hagyja üresen ha a torrent könyvtárába szeretné)";
 theUILang.unzipNotFound	= "Csomagolás bővitmény: rTorrent felhasználó nem fér hozzá az 'unzip' programhoz.";
 theUILang.unrarNotFound	= "Csomagolás bővitmény: rTorrent felhasználó nem fér hozzá az 'unrar' programhoz.";
 theUILang.unpackEnabled	= "Engedélyezi az auto kicsomagolást ha a címke";
 theUILang.unpackTorrents	= "Elérési út hozzáfűzéee a kicsomagolás után a torrent adatokhoz";
 theUILang.unpackAddLabel	= "Torrent címke";
 theUILang.unpackAddName	= "Torrent név";

thePlugins.get("unpack").langLoaded();