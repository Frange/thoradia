﻿/*
 * PLUGIN EXTRATIO
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.ratioRulesManager	= "Quản lý quy luật";
 theUILang.mnu_ratiorule	= "Quy luật Tỉ lệ";
 theUILang.ratAddRule		= "Thêm";
 theUILang.ratDelRule		= "Xóa";
 theUILang.ratUpRule		= "Lên";
 theUILang.ratDownRule		= "Xuống";
 theUILang.ratioIfLegend	= "Nếu";
 theUILang.ratLabelContain	= "Nhãn phân loại Torrent có chứa";
 theUILang.ratTrackerContain	= "Địa chỉ máy theo dõi torrent có chứa";
 theUILang.ratTrackerPublic	= "Tất cả máy theo dõi torrent đều là công cộng";
 theUILang.ratTrackerPrivate	= "Một trong số máy theo dõi torrent là riêng tư";
 theUILang.ratioThenLegend	= "Thì";
 theUILang.setRatioTo		= "Đặt tỉ lệ là";
 theUILang.setChannelTo 	= "Đặt băng thông là";
 theUILang.ratioNewRule 	= "Thêm quy luật mới";

thePlugins.get("extratio").langLoaded();