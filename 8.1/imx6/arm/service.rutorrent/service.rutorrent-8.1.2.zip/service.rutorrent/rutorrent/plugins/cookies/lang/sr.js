﻿/*
 * PLUGIN COOKIES
 *
 * Serbian language file.
 *
 * Author: Zoltan Csala (zcsala021 at gmail dot com)
 */

 theUILang.cookiesDesc = "Колачићи (Формат: host|cookie1;cookie2...)";
 theUILang.cookiesName = "Колачићи";

thePlugins.get("cookies").langLoaded();