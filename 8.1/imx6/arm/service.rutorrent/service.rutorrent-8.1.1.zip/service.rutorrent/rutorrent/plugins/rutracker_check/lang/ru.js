﻿/*
 * PLUGIN RUTRACKER_CHECK
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.checkTorrent 	= "Проверить обновление";
 theUILang.chkHdr		= "Проверка обновления торрента";
 theUILang.checkedAt		= "Произведена";
 theUILang.checkedResult	= "Результат";
 theUILang.chkResults		= [
 				  "В процессе",
 				  "Был обновлен",
 				  "Обновление не требуется",
 				  "Возможно, удален",
 				  "Ошибка доступа к трекеру",
 				  "Ошибка взаимодействия с rTorrent",
 				  "Нет необходимости"
 				  ];

thePlugins.get("rutracker_check").langLoaded();