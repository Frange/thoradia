﻿/*
 * PLUGIN COOKIES
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.cookiesDesc = "Cookies (Formaat: site|cookie1;cookie2...)";
 theUILang.cookiesName = "Cookies";

thePlugins.get("cookies").langLoaded();