﻿/*
 * PLUGIN THROTTLE
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.throttles		= "Κανάλια";
 theUILang.throttle		= "Κανάλι";
 theUILang.mnuThrottle		= "Ορισμός καναλιού";
 theUILang.mnuUnlimited 	= "Κανένα κανάλι";
 theUILang.channelName		= "Όνομα";
 theUILang.channelDefault	= "Προεπιλεγμένο κανάλι";

thePlugins.get("throttle").langLoaded();