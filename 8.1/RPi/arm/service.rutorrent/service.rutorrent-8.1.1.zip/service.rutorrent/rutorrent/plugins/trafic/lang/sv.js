﻿/*
 * PLUGIN TRAFFIC
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.traf 		= "Trafik";
 theUILang.perDay		= "Per dag";
 theUILang.perMonth		= "Per månad";
 theUILang.perYear		= "Per år";
 theUILang.allTrackers		= "Alla trackers";
 theUILang.ClearButton		= "Töm";
 theUILang.ClearQuest		= "Vill du verkligen tömma statestik för markerad(e) tracker(s)?"; 
 theUILang.selectedTorrent	= "Markerad torrent(s)";
 theUILang.ratioDay		= "Ratio/dag";
 theUILang.ratioWeek		= "Ratio/vecka";
 theUILang.ratioMonth		= "Ratio/månad";
