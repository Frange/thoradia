﻿/*
 * PLUGIN TRAFFIC
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.traf 		= "Ruch";
 theUILang.perDay		= "Przez dzień";
 theUILang.perMonth		= "Przez miesiąc";
 theUILang.perYear		= "Przez rok";
 theUILang.allTrackers		= "Wszystkie trackery";
 theUILang.ClearButton		= "Wyczyść";
 theUILang.ClearQuest		= "Czy na pewno chcesz wyczyścić statystyki dla tego trackera?";
 theUILang.selectedTorrent	= "Wybrany torrent(y)";
 theUILang.ratioDay		= "Ratio/dzień";
 theUILang.ratioWeek		= "Ratio/tydzień";
 theUILang.ratioMonth		= "Ratio/miesiąc";
