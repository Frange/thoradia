﻿/*
 * PLUGIN THROTTLE
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.throttles		= "Kanaler";
 theUILang.throttle		= "Kanal";
 theUILang.mnuThrottle		= "Ange kanal";
 theUILang.mnuUnlimited 	= "Ingen kanal";
 theUILang.channelName		= "Namn";
 theUILang.channelDefault	= "Standardkanal";

thePlugins.get("throttle").langLoaded();
